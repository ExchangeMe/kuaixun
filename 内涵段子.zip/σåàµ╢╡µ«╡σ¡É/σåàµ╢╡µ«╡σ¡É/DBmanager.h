//
//  DBmanager.h
//  LimitFree1603
//
//  Created by qianfeng1 on 16/5/25.
//  Copyright (c) 2016年 shishu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommonModel.h"
@interface DBmanager : NSObject

+(instancetype)sharedManager;
-(BOOL)insertUser:(CommonModel*)model;
-(BOOL)deleteWithModel:(CommonModel *)model;
-(NSArray *)selectAll;
-(BOOL)isExsits:(CommonModel * )model;
@end

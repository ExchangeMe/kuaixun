//
//  DBmanager.m
//  LimitFree1603
//
//  Created by qianfeng1 on 16/5/25.
//  Copyright (c) 2016年 shishu. All rights reserved.
//

#import "DBmanager.h"
#import "FMDatabase.h"

@implementation DBmanager
{
    FMDatabase * _db;//数据库里的操作对象
}
static DBmanager  * _manager = nil;

+(instancetype)sharedManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!_manager) {
            _manager=[[self alloc]init];
        }
    });
    return _manager;
}

-(instancetype)init{
    if (self=[super init]) {
        //数据库存储路径
        NSString * path =[NSHomeDirectory() stringByAppendingString:@"/Documents/applications.db"];
        _db=[[FMDatabase alloc]initWithPath:path];
        if([_db open]){
            //创建表
            NSString * sql = @"create table if not exists applicationInfo(aid varchar(255),imgurl varchar(255),title varchar(300),isVideo integer,videourls varchar(300))";
            if (![_db executeUpdate:sql]) {
                NSLog(@"%@",_db.lastError.localizedDescription);
            }
        }
    }
    return self;
}
//插入
-(BOOL)insertUser:(CommonModel*)model{
    NSString * sql = @"insert into applicationInfo values(?,?,?,?,?)";
    return [_db executeUpdate:sql,model.aid,model.imgurl,model.title,@(model.isVideo),model.videourls];
}
//删除
-(BOOL)deleteWithModel:(CommonModel *)model{
    NSString * sql = @"delete from applicationInfo where aid=?";
    return [_db executeUpdate:sql,model.aid];
    
}
//查询所有
-(NSArray *)selectAll{
    NSString * sql = @"select * from applicationInfo";
    FMResultSet * rs = [_db executeQuery:sql];
    NSMutableArray *models = [NSMutableArray new];
    while ([rs next]) { //首先到第一行  直到下一个为空的时候
        CommonModel *model = [CommonModel new];
        //stringForColumn：获取column的值，参数为column列名
        model.aid = [rs stringForColumn:@"aid"];
        //stringForColumnIndex:参数为列的索引值
        model.imgurl = [rs stringForColumnIndex:1];
        model. title= [rs stringForColumnIndex:2];
        model.isVideo=[rs stringForColumnIndex:3].integerValue;
         model.videourls = [rs stringForColumnIndex:4];
       
        [models addObject:model];
    }
    return models;
}
//检查
-(BOOL)isExsits:(CommonModel * )model{
    NSString * sql = @"select * from applicationInfo where aid=?";
    FMResultSet * rs = [_db executeQuery:sql,model.aid];
    
    return [rs next];
    
}


@end

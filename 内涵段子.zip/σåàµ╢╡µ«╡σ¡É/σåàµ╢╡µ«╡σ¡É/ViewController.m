//
//  ViewController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/5/26.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//


#import "ViewController.h"
#import "HomeViewController.h"


#define KWIDHT [UIScreen mainScreen].bounds.size.width

#define KHEIGHT [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UIScrollViewDelegate>
{
    NSMutableArray * _dataArray;
    NSMutableArray * _btnsArray;
    UIScrollView * _topScrollView;//上面小的
    UIScrollView * _bgScrollView;//下面大的
    UIButton * _tmpBtn;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupVcArr];
    [self setupScroll];
    [self setupTopScroll];
}
#pragma mark--数据源
-(void)setupVcArr{
    _dataArray=[[NSMutableArray alloc]init];
    _btnsArray=[NSMutableArray array ];
    
    for (NSInteger i = 0; i<12;i++) {
        HomeViewController * sub = [[HomeViewController alloc]init];
        sub.index=i;
        [_dataArray addObject:sub];
        [self addChildViewController:sub];//共享导航栏控制器nav
    }
}
#pragma mark--下面大的scrollView
-(void)setupScroll{
    self.automaticallyAdjustsScrollViewInsets=NO;
    _bgScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 40, KWIDHT, KHEIGHT-40)];
    
    _bgScrollView.delegate=self;
    _bgScrollView.pagingEnabled=YES;
    _bgScrollView.showsHorizontalScrollIndicator=NO;
    _bgScrollView.bounces=NO;
    //    _bgScrollView.contentOffset=CGPointMake(0, 0);
    
    HomeViewController * subvc = _dataArray[0];
    subvc.view.frame=CGRectMake(0, 0, KWIDHT, KHEIGHT-40);
    
    [_bgScrollView addSubview:subvc.view];
    
    _bgScrollView.contentSize=CGSizeMake(_dataArray.count*KWIDHT, 0);
    
    [self.view addSubview:_bgScrollView];
    
}

#pragma mark--bgScrollView的delegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = scrollView.contentOffset.x/KWIDHT;
    HomeViewController * subVC = _dataArray[index];
    //判断是否被加父视图
    if (!subVC.view.superview) {
        subVC.view.frame=CGRectMake(KWIDHT*index, 0, KWIDHT,scrollView.bounds.size.height);
        [scrollView addSubview:subVC.view];
    }
    
}
//实时调用 字体颜色变化
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //yanse比例
    CGFloat offsetX=scrollView.contentOffset.x;
    CGFloat offsetRatio=(NSInteger)offsetX%(NSInteger)KWIDHT/KWIDHT;
    NSInteger currPage =(offsetX+KWIDHT/2)/KWIDHT;
    NSInteger nextPage ;
    if (currPage*KWIDHT<offsetX) {
        nextPage=currPage+1;
    }else{
        nextPage=currPage-1;
    }
    
    
    if (offsetRatio!=0) {
        if (currPage>nextPage) {
            currPage=currPage+nextPage;
            nextPage=currPage-nextPage;
            currPage=currPage-nextPage;
        }else if (currPage<nextPage){
            currPage=currPage+nextPage;
            nextPage=currPage-nextPage;
            currPage=currPage-nextPage;
        }
        UIButton * curBtn=_btnsArray[currPage];
        UIButton  * nextBtn = _btnsArray[nextPage];
        [curBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        [nextBtn setTitleColor:[UIColor colorWithRed:0.9 green:0.8*(1-offsetRatio) blue:0.8*(1-offsetRatio) alpha:1] forState:UIControlStateNormal];
           [nextBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//        NSLog(@"%ld,%ld",currPage,nextPage);
        
    }else{//滚动结束 自身一起移动
        //最大偏移量
        UIButton * btn = _btnsArray[currPage];
        if (CGRectGetMidX(btn.frame)-KWIDHT/2 >_topScrollView.contentSize.width-KWIDHT) {
            [_topScrollView setContentOffset:CGPointMake(_topScrollView.contentSize.width-KWIDHT, 0) animated:YES];
        }else if (CGRectGetMidX(btn.frame)<KWIDHT/2){
            [_topScrollView setContentOffset:CGPointZero animated:YES];
        }else{
            [_topScrollView setContentOffset:CGPointMake(CGRectGetMidX(btn.frame)-KWIDHT/2, 0) animated:YES];
        }
        
    }
}

#pragma mark--顶部的scrollView
-(void)setupTopScroll{
    _topScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, 40)];
    _topScrollView.showsHorizontalScrollIndicator=NO;
    
    NSArray * titles =@[
                        @"推荐",@"天下",@"上海",@"旅行",@"美食",
                        @"两性",@"美女",@"灵异",@"电影",@"宠物",
                        @"八卦",@"军事"
                        ];
    
    for (NSInteger i = 0; i<_dataArray.count; i++) {
        
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(i*KWIDHT/4, 0,KWIDHT/4, 40)];
        [btn setTitle:titles[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.titleLabel.font=[UIFont boldSystemFontOfSize:17];
        btn.tag=100+i;
        [btn addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        if (i==0) {
            
            [btn setTitleColor:[UIColor colorWithRed:0.8 green:0 blue:0 alpha:1.0] forState:UIControlStateNormal];
            _tmpBtn=btn;
        }
        [_topScrollView addSubview:btn];
        [_btnsArray addObject:btn];
        
    }
    _topScrollView .contentSize=CGSizeMake(titles.count*(KWIDHT/4), 0);
    [self.view addSubview:_topScrollView];
    
}
-(void)changePage:(UIButton*)btn{
    
    [_tmpBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    NSInteger curPage = _bgScrollView.contentOffset.x/KWIDHT;
    UIButton *curBtn = _btnsArray[curPage];
    [curBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    NSInteger index =btn.tag-100;
    [btn setTitleColor:[UIColor colorWithRed:0.8 green:0 blue:0 alpha:1] forState:UIControlStateNormal];
    _tmpBtn=btn;
    [_bgScrollView setContentOffset:CGPointMake(KWIDHT*index, 0) animated:NO];
    HomeViewController * subVC = _dataArray[index];
    //判断是否被加父视图
    if (!subVC.view.superview) {
        subVC.view.frame=CGRectMake(KWIDHT*index, 0, KWIDHT,_bgScrollView.bounds.size.height);
        [_bgScrollView addSubview:subVC.view];
    }
    
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
//
//  MyFavoriteVC.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/17.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "MyFavoriteVC.h"
#import "MyUtiles.h"
#import "DBmanager.h"
#import "Const.h"
#import "CommonModel.h"
#import "UIImageView+WebCache.h"
#import "LFRankDetailVC.h"
@interface MyFavoriteVC ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;
}
@end

@implementation MyFavoriteVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden=YES;
    self.navigationController.navigationBarHidden=NO;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIScreenEdgePanGestureRecognizer * moveTap=[[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(leftBtnClick)];
    moveTap.edges=UIRectEdgeLeft;
    [self.view addGestureRecognizer:moveTap];
    
    self.view.backgroundColor=[UIColor whiteColor];
    _dataArray=[[NSMutableArray alloc]init];
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT-64) style:UITableViewStylePlain];
    
    _tb.delegate=self;
    _tb.dataSource=self;
    UIButton * btn = [MyUtiles createBtnWithFrame:CGRectMake(16, 28, 13, 22) title:nil normalBgImg:@"2333" highlightedBgImg:nil target:self action:@selector(leftBtnClick)];
    btn.imageView.contentMode=UIViewContentModeScaleAspectFit;
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:btn];
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 80, 30)];
    label.text=@"我的收藏";
    label.textColor=[UIColor whiteColor];
    self.navigationItem.titleView=label;
    [self loadData];
    [_tb reloadData];
}
-(void)leftBtnClick{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)loadData{
    
    _dataArray=[[DBmanager sharedManager]selectAll].mutableCopy;

      
    if(_dataArray.count==0){
        UIImage * image=[UIImage imageNamed:@"nofavorite_loading_night"];
        UIImageView * imagev=[[UIImageView alloc]initWithFrame:CGRectMake(KWIDHT/2-80, KHEIGHT/2-64-52, 160, 104)];
        imagev.backgroundColor=[UIColor clearColor];
        imagev.image=image;
//        imagev.center=self.view.center;
        [self.view addSubview:imagev];
        
       
    }else{
          [self.view addSubview:_tb];
        _tb.tableFooterView = [[UIView alloc] init];
    }
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    }
    
    CommonModel * model = _dataArray[indexPath.row];
    cell.textLabel.text=model.title;
    cell.textLabel.font=[UIFont systemFontOfSize:15];
    cell.textLabel.numberOfLines=2;
    

    CGSize size = CGSizeMake(80, 68);
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
    //调整image的大小
    UIGraphicsBeginImageContext(size);
    CGRect imageRect=CGRectMake(0.0, 0.0, size.width, size.height);
    [cell.imageView.image drawInRect:imageRect];
    cell.imageView.image=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    cell.selectionStyle=UITableViewCellSelectionStyleNone;

    return cell;
    
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{

    CommonModel * model =_dataArray[indexPath.row];
    BOOL isSuccess = [[DBmanager sharedManager]deleteWithModel:model];
    if (isSuccess) {
       
        [_dataArray removeObjectAtIndex:indexPath.row];
      
        [_tb deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
       
    }
    
}
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonModel * model =_dataArray[indexPath.row];
    LFRankDetailVC * vc =[[LFRankDetailVC alloc]init];
    
    vc.index=0;
    vc.aid=model.aid;
    if (model.isVideo==1) {
    vc.category=@"video";
    vc.videourls=model.videourls;
    }
    vc.isVideo=model.isVideo;
    vc.imgurl=model.imgurl;
    
    
    [self.navigationController pushViewController:vc animated:YES];
    self.tabBarController.tabBar.hidden=YES;
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  LFRightNavVC.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/14.
//  Copyright © 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LFRightNavVC : UIViewController
//@property (nonatomic ,copy)NSString
@end

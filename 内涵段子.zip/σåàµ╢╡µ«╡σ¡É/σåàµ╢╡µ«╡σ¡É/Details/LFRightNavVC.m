//
//  LFRightNavVC.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/14.
//  Copyright © 2016年 LU_FENG. All rights reserved.
//

#import "LFRightNavVC.h"
#import "MyUtiles.h"
#import "Const.h"
#import "MJRefresh.h"
#import "AFNetworking.h"
#import "CommonModel.h"
#import "OnePicCell.h"
#import "LFRankDetailVC.h"
@interface LFRightNavVC ()<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIGestureRecognizerDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;
    UISearchBar * _searchBar;
    NSString * _keywords;
    NSInteger _curPage;
}
@end

@implementation LFRightNavVC

- (void)viewDidLoad {
    [super viewDidLoad];
      _dataArray =[NSMutableArray array ];
    
    UIScreenEdgePanGestureRecognizer * moveTap=[[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(leftBtnClick)];
    moveTap.edges=UIRectEdgeLeft;
    [self.view addGestureRecognizer:moveTap];
//    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setBackgroundColor:[UIColor colorWithWhite:0.8 alpha:0.6]];
    UIButton * btn = [MyUtiles createBtnWithFrame:CGRectMake(16, 28, 13, 22) title:nil normalBgImg:@"2444" highlightedBgImg:nil target:self action:@selector(leftBtnClick)];
    btn.imageView.contentMode=UIViewContentModeScaleAspectFit;
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:btn];
    _searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, 0, 40)];
    _searchBar.delegate = self;
//    _searchBar.backgroundColor=[UIColor colorWithWhite:0.5 alpha:0.5];
    _searchBar.placeholder=@"搜索";
    [_searchBar becomeFirstResponder];
    self.navigationItem.titleView=_searchBar;
    
//设置tableView
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, KWIDHT, KHEIGHT-64) style:UITableViewStylePlain];
    _tb.delegate=self;
    _tb.dataSource=self;
    [_tb registerNib:[UINib nibWithNibName:@"OnePicCell" bundle:nil] forCellReuseIdentifier:@"OnePicCell"];
    
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    
   

    _curPage=1;
    
    _tb.footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self loadMore];
    }];
    
}


-(void)loadMore{
    _curPage++;
    
    [self loadData];
}
-(void)loadData{
    
   
  
    NSString * urlStr = [NSString stringWithFormat:KSeachUrl,(long)_curPage, _keywords];
    //    NSLog(@"%@",_lastId);
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"article_list"]];
        [_dataArray addObjectsFromArray:models];
        [_tb reloadData];
     
//解析成功后加入cell
        [self.view addSubview:_tb];
     
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        UIImageView * imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
        imageView.center=self.view.center;
        imageView.image=[UIImage imageNamed:@"field"];
        imageView.contentMode=2;
        imageView.clipsToBounds=YES;
        [self.view addSubview:imageView];
        
    }];
    
    [_tb reloadData];
    
    

}
#pragma mark searchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    searchBar.showsCancelButton=YES;
    UIView * searchBarSubView = searchBar.subviews.lastObject;
    [searchBarSubView.subviews.lastObject setTitle:@"取消"];
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    searchBar.showsCancelButton=NO;
}
//点击取消按钮
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];

}
//点击搜索按钮
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
    [_searchBar resignFirstResponder];
    _keywords=searchBar.text;
    if (_dataArray) {
        [_dataArray removeAllObjects];
    }
    [self loadData];
    
    
    searchBar.showsCancelButton=NO;
}
#pragma mark CellDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    OnePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"OnePicCell" forIndexPath:indexPath];
    cell.model=_dataArray[indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonModel * model = _dataArray[indexPath.row];
    LFRankDetailVC * vc =[[LFRankDetailVC alloc]init];
    vc.index=0;
    vc.aid=model.aid;
    vc.isVideo=0;
    vc.imgurl=model.imgurl;
    vc.niceTitle=model.title;
    
    [self.navigationController pushViewController:vc animated:YES];
    self.tabBarController.tabBar.hidden=YES;
    
}


#pragma mark 返回按键

-(void)leftBtnClick{
    [self.navigationController popToRootViewControllerAnimated:YES];
    self.tabBarController.tabBar.hidden=NO;
     [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"上导航"] forBarMetrics:UIBarMetricsDefault];
    [_searchBar resignFirstResponder];
    [_dataArray removeAllObjects];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  LFRankDetailVC.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/12.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h> 

@interface LFRankDetailVC : UIViewController
@property (nonatomic ,assign)NSInteger index;
@property (nonatomic ,copy)NSString * aid;
@property (nonatomic ,copy)NSString * weinxin;
@property (nonatomic ,copy)NSString * videourls;
@property (nonatomic ,copy)NSString * category;
@property (nonatomic ,strong)MPMoviePlayerViewController * mpPlayer;
@property (nonatomic ,assign)NSInteger   isVideo;
@property (nonatomic ,copy)NSString * imgurl;
@property (nonatomic ,copy)NSString * niceTitle;

-(void)configUI;
@end

//
//  LFLeftNavVC.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/14.
//  Copyright © 2016年 LU_FENG. All rights reserved.
//

#import "LFLeftNavVC.h"
#import "Const.h"
#import "MyUtiles.h"
#import "MyFavoriteVC.h"
@interface LFLeftNavVC ()
{
    UIView * _view;
}
@end

@implementation LFLeftNavVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
  
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self configUI];
    
    UIControl * control = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, 44, 55)];
    control.backgroundColor=[UIColor clearColor];
    UIImageView * backImage=[[UIImageView alloc]initWithFrame:CGRectMake(16, 28, 13, 22)];
    backImage.image=[UIImage imageNamed:@"2333"];
    [control addSubview:backImage];
    [control addTarget:self action:@selector(leftBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:control];
    
    UIScreenEdgePanGestureRecognizer * moveTap=[[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(leftMove)];
    moveTap.edges=UIRectEdgeLeft;
    [self.view addGestureRecognizer:moveTap];
    
}
-(void)leftMove{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)configUI{
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT/3)];
    view.backgroundColor=[UIColor colorWithWhite:0.1 alpha:0.4];
    [self.view addSubview:view];
    
    UIButton * userBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
    userBtn.center= view.center;
    userBtn.layer.cornerRadius=50;
    userBtn.clipsToBounds=YES;
    userBtn.layer.borderWidth=2;
    userBtn.layer.borderColor=[UIColor whiteColor].CGColor;
    [userBtn setBackgroundImage:[UIImage imageNamed:@"mine_press"] forState:UIControlStateNormal];
    [userBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    userBtn.tag=11;
//    
    userBtn.enabled=NO;
    [view addSubview:userBtn];
    
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 20)];
    label.center=CGPointMake(userBtn.center.x, userBtn.center.y+80);
    label.text=@"快讯会员";
    label.font=[UIFont systemFontOfSize:16];
//    [view addSubview:label];
    
    
    NSArray * titles =@[@"我的收藏",@"申请快讯号",@"我的关注",@"关于我们",@"邀请好友"];
//    NSArray * headImageNames =@[@"i-star",@"i-gamecenter@2x",@"i-pic",@"i-ipadown",@""];
    NSArray * headImageNames =@[@"a",@"b",@"c",@"d",@""];
    /*
     count=titles.count
     */
#pragma mark--分享按钮
    NSInteger count=1;
    for (NSInteger i = 0 ; i<count; i++) {
        UIControl * control = [[UIControl alloc]initWithFrame:CGRectMake(0, view.frame.size.height+2+50*i, KWIDHT, 50)];
        UIImageView * imageView  =[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 30,30)];
        imageView.image=[UIImage imageNamed:headImageNames[i]];
        
        UILabel * label =[[UILabel alloc]initWithFrame:CGRectMake(50, 10, KWIDHT-30, 30)];
        label.text=titles[i];
        label.font=[UIFont systemFontOfSize:17];
        
        [control addTarget:self action:@selector(controlClick:) forControlEvents:UIControlEventTouchUpInside];
        control.tag=100+i;
        
        [control addSubview:imageView];
        [control addSubview:label];
        [self.view addSubview:control];
        
        if (i==4) {
            control.frame=CGRectMake(0, view.frame.size.height+2+50*4+15, KWIDHT,50);
            label.frame=CGRectMake(0, 10, KWIDHT, 30);
            imageView.frame=CGRectMake(0, 0, 0, 0);
            label.textColor=[UIColor redColor];
            label.textAlignment=NSTextAlignmentCenter;
            
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, 1)];
            view.backgroundColor=[UIColor lightGrayColor];
            [control addSubview:view];
            UIView * view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 49, KWIDHT, 1)];
            view1.backgroundColor=[UIColor lightGrayColor];
            [control addSubview:view1];
            
        }
  
        
    }
    
}
-(void)controlClick:(UIControl *)contorl{


    if (contorl.tag==104) {
        [self insertFriend];
    }else{
        
        contorl.backgroundColor=[UIColor lightGrayColor];
        [UIView animateWithDuration:0.2 animations:^{
            contorl.backgroundColor=[UIColor whiteColor];
        }];
    }
    if (contorl.tag==100) {
        
        MyFavoriteVC * vc =[[MyFavoriteVC alloc]init];
    
        [self.navigationController pushViewController:vc animated:YES];
        
        
    }
    
}

-(void)btnClick:(UIButton *)btn{
    
    
    if (btn.tag==104) {
        [_view removeFromSuperview];
    }else{

    }
    
}

-(void)leftBtnClick{
    if ([_delegate respondsToSelector:@selector(doSomething:)]) {
        [_delegate doSomething:_index];
    }
   
    [self.navigationController popToRootViewControllerAnimated:YES];

}

#pragma mark--邀请好友跳出来的
-(void)insertFriend{
    
    _view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT)];
    _view.backgroundColor=[UIColor colorWithWhite:0 alpha:0.7];

    
    NSArray * btnImages=@[@"qqkongjian_popover",@"login_weixin",@"login_sina",@"qq_popover"];
    NSArray * btnNames=@[@"QQ空间",@"微信好友",@"新浪微博",@"QQ好友"];
    for (NSInteger i = 0 ; i<4; i++) {
    UIButton * Btn = [[UIButton alloc]initWithFrame:CGRectMake(KWIDHT/2-20-60+(40+60)*(i%2), KHEIGHT/2-20-60+(40+60)*(i/2), 58, 58)];
    
    UILabel * label =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 80, 20)];
        label.center=CGPointMake(Btn.center.x, Btn.center.y+29+13);
        label.text=btnNames[i];
        label.textAlignment=1;
        label.font=[UIFont systemFontOfSize:12];
        label.textColor=[UIColor whiteColor];
        
    Btn.layer.cornerRadius=29;
        Btn.contentMode=UIViewContentModeScaleAspectFill;
    Btn.clipsToBounds=YES;
    [Btn setBackgroundImage:[UIImage imageNamed:btnImages[i]] forState:UIControlStateNormal];
        [Btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    Btn.tag=20+i;

    [_view addSubview:Btn];
    [_view addSubview:label];
    
    }
    UIButton * btn =[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 58, 58)];
    btn.center=CGPointMake(KWIDHT/2, KHEIGHT/2+140);
    [btn setBackgroundImage:[UIImage imageNamed:@"yuanquancha"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag=104;
    [_view addSubview:btn];
    [self.view insertSubview:_view aboveSubview:[self.view.subviews lastObject]];
    

}

-(void)touchesBegan:(NSSet*)touches withEvent:(UIEvent *)event{
        [_view removeFromSuperview];
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

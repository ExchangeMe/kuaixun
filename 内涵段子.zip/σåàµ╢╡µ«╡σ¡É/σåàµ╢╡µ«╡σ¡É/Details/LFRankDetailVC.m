//
//  LFRankDetailVC.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/12.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "LFRankDetailVC.h"
#import "Const.h"
#import "MyUtiles.h"
#import "AFNetworking.h"
#import "CommonModel.h"
#import "Masonry.h"
#import "OnePicCell.h"
#import <AVFoundation/AVAudioSession.h>
#import <AVKit/AVPlayerViewController.h>
#import <AVFoundation/AVBase.h>
#import <AVFoundation/AVPlayer.h>
#import <AVFoundation/AVPlayerItem.h>
#import <AVFoundation/AVFoundation.h>
#import "SVProgressHUD.h"

#import "DBmanager.h"


@interface LFRankDetailVC ()<UITableViewDelegate,UITableViewDataSource,UIWebViewDelegate>
{
    UIWebView * _webView;
    UITableView * _tb;
    NSMutableArray * _dataArray;
    
    AVPlayerViewController * _vc;
    AVPlayer * _play;
    UIButton * _tmpBtn;
    UIView * _pushView;
    NSInteger _touchCount;
    
    
   
}
@end

@implementation LFRankDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];
    
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT-64) style:UITableViewStyleGrouped];
    _tb.delegate=self;
    _tb.dataSource=self;
    [SVProgressHUD show];
    [self configUI];
    
    UIScreenEdgePanGestureRecognizer * moveTap=[[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(leftBtnClick)];
    moveTap.edges=UIRectEdgeLeft;
    [self.view addGestureRecognizer:moveTap];
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"上导航"] forBarMetrics:UIBarMetricsDefault];
}

-(void)configUI{
    self.automaticallyAdjustsScrollViewInsets=NO;
//左边按钮（返回）
    UIButton * btn = [MyUtiles createBtnWithFrame:CGRectMake(0, 0, 13, 22) title:nil normalBgImg:@"2333" highlightedBgImg:nil target:self action:@selector(leftBtnClick)];
    btn.imageView.contentMode=UIViewContentModeScaleAspectFit;
    
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:btn];
//右边按钮（收藏和分享）

    UIButton * shareBtn =[MyUtiles createBtnWithFrame:CGRectMake(0, 0, 24, 22) title:nil normalBgImg:@"share" highlightedBgImg:nil target:self action:@selector(rightBtnClick:)];
    shareBtn.tag=101;
    UIBarButtonItem * item=[[UIBarButtonItem alloc]initWithCustomView:shareBtn];
    self.navigationItem.rightBarButtonItems=@[item];
    
//
    _webView=[[UIWebView alloc]initWithFrame:CGRectMake(8, 8, KWIDHT-16, KHEIGHT)];
  
    _webView.delegate=self;
    _webView.scalesPageToFit = NO;//自动对页面进行缩放以适应屏幕

   _dataArray=[NSMutableArray array];


    [self.view addSubview:_tb];

    [_tb registerNib:[UINib nibWithNibName:@"OnePicCell" bundle:nil] forCellReuseIdentifier:@"OnePicCell"];
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    
    [_tb reloadData];
//非公众号的详情页
    if (_index==0) {
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 80, 30)];
        label.text=@"文章详情";
        label.textAlignment=NSTextAlignmentCenter;
        [self wenzhangDetail];
        
//判断传进来的是什么类的详情
        if([_category isEqualToString:@"video"]){
            
            NSURL * url = [NSURL URLWithString:_videourls];
            _vc =[[AVPlayerViewController alloc]init];
            _play = [[AVPlayer alloc]initWithURL:url];
            _vc.player=_play;
            [_play play];
            UIView * view =[[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT/3)];
            _vc.view.frame=view.frame;
            [view addSubview:_vc.view];
            [self.view addSubview:view];
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
            [SVProgressHUD dismiss];
            _tb.frame=CGRectMake(0, KHEIGHT/3, KWIDHT, KHEIGHT*2/3-64);
           
        }
        else{
         _tb.tableHeaderView=_webView;
        }
        

        self.navigationItem.titleView=label;
        [self loadData];
        
    }else if(_index==1) {
        self.navigationItem.title=@"公众号详情页";
        [self gongzonghaoDetail];
        [_tb removeFromSuperview];
    }
    
}

#pragma mark -左边返回
-(void)leftBtnClick{
    [SVProgressHUD dismiss];
   
    [self.navigationController popViewControllerAnimated:YES];
//    [_vc.player play];
}
#pragma mark-右边分享和收藏
-(void)rightBtnClick:(UIButton *)btn{
//第一次点击有用  后面点击都没用  需要移除后才能再点击
    
    
    if (_touchCount==0) {
    _pushView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT)];
    _pushView.backgroundColor=[UIColor colorWithWhite:0 alpha:0.4];
    
    UIView * btnOnView=[[UIView alloc]initWithFrame:CGRectMake(0, KHEIGHT*3/5-64, KWIDHT, KHEIGHT*2/5)];
    btnOnView.backgroundColor=[UIColor whiteColor];
    [_pushView addSubview:btnOnView];
    
    NSArray * btnImages=@[@"qqkongjian_popover",@"login_weixin",@"login_sina",@"qq_popover"];
    NSArray * btnNames=@[@"QQ空间",@"微信好友",@"新浪微博",@"QQ好友"];
        /*
         第三方分享
        NSInteger count=btnNames.count;
         */
#pragma mark-分享按钮更改
        NSInteger count=btnNames.count;
      /**/
        NSLog(@"123");
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, KHEIGHT*2/5+64)];
        imgView.image=[UIImage imageNamed:@"123.jpg"];
//        [btnOnView addSubview:imgView];
        /**/
    for (NSInteger i = 0 ; i<count; i++) {
        UIButton * Btn = [[UIButton alloc]initWithFrame:CGRectMake(25+(KWIDHT-24)/4*(i%4),15, 58, 58)];
        
        UILabel * label =[[UILabel alloc]initWithFrame:CGRectMake(25+(KWIDHT-24)/4*(i%4), 15+58+10, 58, 17)];
        label.text=btnNames[i];
        label.textAlignment=1;
        label.font=[UIFont systemFontOfSize:12];
        label.textColor=[UIColor blackColor];
        
        Btn.layer.cornerRadius=29;
        Btn.contentMode=UIViewContentModeScaleAspectFill;
        Btn.clipsToBounds=YES;
        [Btn setBackgroundImage:[UIImage imageNamed:btnImages[i]] forState:UIControlStateNormal];
        [Btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        Btn.tag=20+i;
        
        [btnOnView addSubview:Btn];
        [btnOnView addSubview:label];
    }
    
    UIButton * likeBtn =[MyUtiles createBtnWithFrame:CGRectMake(0, btnOnView.frame.size.height-40-10-40, KWIDHT, 40) title:nil normalBgImg:@"bluebutton" highlightedBgImg:nil target:self action:@selector(btnClick:)];
    [likeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    likeBtn.tag=101;
        _tmpBtn=likeBtn;
//    [likeBtn setTitle:@"已收藏" forState:UIControlStateSelected];
      
    [btnOnView addSubview:likeBtn];
    
    UIButton * cancelBtn=[MyUtiles createBtnWithFrame:CGRectMake(0, btnOnView.frame.size.height-40, KWIDHT, 40) title:@"取  消" normalBgImg:@"cancelbtn" highlightedBgImg:nil target:self action:@selector(btnClick:)];
    cancelBtn.tag=100;

    [btnOnView addSubview:cancelBtn];
    
    [UIView animateWithDuration:0.5 animations:^{
        [self.view insertSubview:_pushView aboveSubview:[self.view.subviews lastObject]];
    }];
    
        _touchCount=1;
    }
    
    [self checkIsExsits];
    
}
#pragma mark-收藏按钮和取消按钮
-(void)btnClick:(UIButton *)btn{
    if (btn.tag==100) {
        _touchCount=0;
        [_pushView removeFromSuperview];
    }else if (btn.tag==101){

     
        CommonModel * model =[[CommonModel alloc]init];
        model.aid=_aid;
        model.imgurl=_imgurl;
        model.title=_niceTitle;
        model.isVideo=_isVideo;
        model.videourls=_videourls;
        if (model.aid==nil) {
            return;
        }
       
        BOOL isSuccess = [[DBmanager sharedManager]insertUser:model];
        if (isSuccess) {
            _tmpBtn.enabled=NO;
            [_tmpBtn setTitle:@"已收藏" forState:UIControlStateNormal];
        
        }
    }
}

-(void)wenzhangDetail{
    NSString  * urlStr = [NSString stringWithFormat:KWZPushUrl,_aid];
     NSURLRequest * request=[[NSURLRequest alloc]initWithURL:[NSURL URLWithString:urlStr]];
    [_webView loadRequest:request];
//    [_webView reload];
   
    
}

-(void)gongzonghaoDetail{
    NSString  * urlStr = [NSString stringWithFormat:KGZHPushUrl,_weinxin];
    NSURLRequest * request=[[NSURLRequest alloc]initWithURL:[NSURL URLWithString:urlStr]];
    [_webView loadRequest:request];
    [_webView reload];
    [self.view addSubview:_webView];
}


#pragma mark 设置web的高度
-(void)webViewDidFinishLoad:(UIWebView*)webView{

    CGFloat webViewHeight=[webView.scrollView contentSize].height;
    CGRect newFrame =  webView.frame;
    newFrame.size.height= webViewHeight;
    _webView.frame= newFrame;
    
     if(![_category isEqualToString:@"video"]){
         _tb.tableHeaderView=_webView;
          [SVProgressHUD dismiss];
     }
  
    _webView.scrollView.frame=newFrame;
    _webView.scrollView.contentSize=CGSizeMake(newFrame.size.width, newFrame.size.height);

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *injectionJSString = @"var script = document.createElement('meta');"
        "script.name = 'viewport';"
        "script.content=\"width=device-width, initial-scale=1.0,maximum-scale=1.0, minimum-scale=1.0, user-scalable=0\";"
        "document.getElementsByTagName('head')[0].appendChild(script);";;
        [_webView stringByEvaluatingJavaScriptFromString:injectionJSString];
        _webView.scrollView.maximumZoomScale=1.0;
        _webView.scrollView.minimumZoomScale=1.0;
        _webView.scrollView.zoomScale = 1.0;
    });
    
    
}

//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
//{
//    NSLog(@"%@",request.URL);
//    return YES;
//}

#pragma mark get data

-(void)loadData{
    NSString * urlStr = [NSString stringWithFormat:KXiangGuangUrl,_aid];
   
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:urlStr parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"article_list"]];
        [_dataArray addObjectsFromArray:models];
        [_tb reloadData];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        
    }];
    
    [_tb reloadData];
    
}

#pragma mark--delegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 60;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    return @"相关文章";
}
-(NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
    return @"全部评论\n\n                      没有更多评论~";
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    OnePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"OnePicCell" forIndexPath:indexPath];
    cell.model=_dataArray[indexPath.row];
  
    return cell;
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
  
    
    LFRankDetailVC * newVc =[[LFRankDetailVC alloc]init];
    CommonModel * model =_dataArray[indexPath.row];
    if(model.videourls&&_isVideo==1){
        newVc.videourls=model.videourls;;
        newVc.category=@"video";
        newVc.isVideo=1;
    }
        newVc.aid=model.aid;
//        [_dataArray removeAllObjects];
//        [self configUI];
    
    [self.navigationController pushViewController:newVc animated:YES];
    
    
}
#pragma mark 分享页消失
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [_pushView removeFromSuperview];
    _touchCount=0;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



//检查是否存在本地收藏
-(void)checkIsExsits{
    CommonModel * model = [[CommonModel alloc]init];
    model.aid=_aid;
    model.imgurl=_imgurl;
    model.title=_niceTitle;
    model.isVideo=_isVideo;
    
    if ([[DBmanager sharedManager]isExsits:model]) {
        _tmpBtn.enabled=NO;
        
        [_tmpBtn setTitle:@"已收藏" forState:UIControlStateNormal];
    }else{
        [_tmpBtn setTitle:@"收 藏" forState:UIControlStateNormal];
    }
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [_vc.player pause];
    [_vc.player setRate:0.0];

}


@end

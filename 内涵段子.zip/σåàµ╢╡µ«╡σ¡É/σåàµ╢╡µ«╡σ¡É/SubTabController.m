//
//  SubTabController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/5/26.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "SubTabController.h"
#import "UITabBarController+LF.h"
#import "HomeViewController.h"
#import "VideoViewController.h"
#import "HotViewController.h"
#import "RankViewController.h"
#import "MyUtiles.h"
#import "ViewController.h"
#import "LFLeftNavVC.h"
#import "LFRightNavVC.h"
#import "VideoChildControlls.h"
@interface SubTabController ()<LFLeftNavVCDelegate>
{
    NSArray * _controllers;
    NSInteger _curCount;
}
@end

@implementation SubTabController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSArray * titles =@[@"首页",@"视频",@"热点",@"排行榜"];
    NSArray * btnNames=@[@"recommendation_1",@"publish_video",@"broadwood_1",@"classification_1"];
    NSMutableArray * btnSels=@[].mutableCopy;
    for (NSInteger i = 0 ; i<titles.count; i++) {
        [btnSels addObject:[NSString stringWithFormat:@"%@_press",btnNames[i]]];
    }
    
    NSArray * controllers = @[[ViewController new],[VideoViewController new],[HotViewController new],[RankViewController new]];
    _controllers=controllers;
    [UITabBarController printChildViewControlsWithViewControllers:controllers tabBarTitiles:titles andTabBarimages:btnNames andTabBarSelectImg:btnSels andTarget:self];
   

    for (UIViewController * controler in controllers) {
    
        UIImage * image =[UIImage imageNamed:@"上导航"];

        [controler.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];

        
        controler.navigationController.navigationBar.contentMode=UIViewContentModeScaleToFill;
        
        
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 100)];
        label.font=[UIFont boldSystemFontOfSize:22];
        label.textAlignment=NSTextAlignmentCenter;
        label.text= [NSString stringWithFormat:@"快讯·%@",controler.title];
        if (controler==controllers[0]) {
          label.text= @"快讯·段子";
        }
        label.textColor=[UIColor whiteColor];
        controler.navigationItem.titleView=label;
        
        UIButton * leftBtn =  [MyUtiles createBtnWithFrame:CGRectMake(0, 0, 34, 30) title:nil normalBgImg:@"mine_press" highlightedBgImg:nil target:self action:@selector(leftBtnClick:)];
        leftBtn.tag=_curCount;
        
        UIBarButtonItem * barBtn =[[UIBarButtonItem alloc]initWithCustomView:leftBtn];
        
        controler.navigationItem.leftBarButtonItem=barBtn;
       
        UIButton * rightBtn = [MyUtiles createBtnWithFrame:CGRectMake(0, 0, 34, 30) title:nil normalBgImg:@"search" highlightedBgImg:nil target:self action:@selector(rightBtnbtnClick:)];
        rightBtn.tag=_curCount;
         controler.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:rightBtn];
        controler.tabBarController.tabBar.tintColor=[UIColor redColor];
    
       _curCount++;
    }
    
}
-(void)leftBtnClick:(UIButton *)btn{
    NSLog(@"%ld",(long)btn.tag);
    LFLeftNavVC * vc =[[LFLeftNavVC alloc]init];
    vc.index=btn.tag;

    
    UIViewController * curVC= _controllers[btn.tag];
     vc.delegate=self;
    [curVC.navigationController pushViewController:vc animated:YES];
    curVC.tabBarController.tabBar.hidden=YES;
    
}

-(void)doSomething:(NSInteger)index{
    UIViewController * curVC= _controllers[index];
    curVC.navigationController.navigationBarHidden=NO;
    curVC.tabBarController.tabBar.hidden=NO;
 
}

-(void)rightBtnbtnClick:(UIButton *)btn{
   
    LFRightNavVC * vc =[[LFRightNavVC alloc]init];
//    vc.index=btn.tag;
    
    UIViewController * curVC= _controllers[btn.tag];
   
    [curVC.navigationController pushViewController:vc animated:YES];
    //    curVC.navigationController.navigationBarHidden=YES;
    curVC.tabBarController.tabBar.hidden=YES;
}

#pragma mark--剪上边的图片
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    UIGraphicsBeginImageContext(size);
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

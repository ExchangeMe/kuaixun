//
//  UITabBarController+LF.m
//  TabBarWiithNavPage
//
//  Created by qianfeng1 on 16/5/26.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "UITabBarController+LF.h"

@implementation UITabBarController (LF)
/**
 *  tabBar子视图快速建立
 *
 *  @param Controllers   存放子视图的对象，数组格式
 *  @param tabBarTitiles tabBar的标题
 *  @param tabBarimages  tabBar图标
 *  @param tabBarSecImgs tabBar点击后的图片
 *  @param target        一般填self ，tabBarViewController视图
 */
+(void)printChildViewControlsWithViewControllers:(NSArray *)Controllers tabBarTitiles:(NSArray *)tabBarTitiles andTabBarimages:(NSArray *)tabBarimages andTabBarSelectImg:(NSArray * )tabBarSecImgs andTarget:(UITabBarController *)target{
    
    NSMutableArray *vcArr = [[NSMutableArray alloc]init];
   
    for (NSInteger i = 0; i<tabBarTitiles.count; i++) {
        UIViewController *vc=Controllers[i];
        
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:vc];
        vc.view.backgroundColor=[UIColor whiteColor];
        //设置标题
        vc.title = tabBarTitiles[i];
        //设置常态下图片
        vc.tabBarItem.image = [[UIImage imageNamed:tabBarimages[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        //设置选中下图片
        NSString *selectImgName = tabBarSecImgs[i];
        //去除渲染
        vc.tabBarItem.selectedImage = [UIImage imageNamed:selectImgName];
//                                       imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        //改变文字颜色
        
        //NSFontAttributeName:[UIFont systemFontOfSize:16]
        [vc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor],NSFontAttributeName:[UIFont systemFontOfSize:10]} forState:UIControlStateSelected];
        [vcArr addObject:nav];
    }
    target.viewControllers = vcArr;
    
    
    
}


@end

//
//  Const.h
//  LimitFree
//
//  Created by shishu on 16/2/29.
//  Copyright © 2016年 shishu. All rights reserved.
//

#ifndef Const_h
#define Const_h

//接口
#define KWIDHT [UIScreen mainScreen].bounds.size.width

#define KHEIGHT [UIScreen mainScreen].bounds.size.height
//分享
#define KFenxiangUrl (@"http://api.myhaowai.com/api/article/get_template?template=shareArticle&aid=%@")

/**
 1.推荐
 */
#define KTuiJianUrl  (@"http://api.myhaowai.com/api/article/get_commend_list?devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&lastId=%@&lastTime=20160618200711&pageNumber=%ld&pcode=021000&version=3.1")
/**
 2.视频
 */
 #define KShiPinUrl  (@"http://api.myhaowai.com/api/article/get_video_list?devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&lastId=%@&&lastTime=20160618200711&pageNumber=%ld&pcode=021000&version=3.1")
/**
 3.热点
 */
#define KReDianUrl (@"http://api.myhaowai.com/api/article/get_hot_list?devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&lastId=%@&&lastTime=20160618200711&pageNumber=%ld&pcode=021000&version=3.1")
/**
 4.排行榜
 */
#define KRankgoryUrl (@"http://api.myhaowai.com/api/rank/get_rank_category_list?devid=D667C6BB2828EC396C5BD4139CE5C538&pcode=021000&version=3.1")
//文章
#define KWenzhangURl (@"http://api.myhaowai.com/api/rank/get_article_by_cateid?cateid=%@&devid=D667C6BB2828EC396C5BD4139CE5C538&pcode=021000&version=3.1")
//公众号
#define KGongzonghaoUrl (@"http://api.myhaowai.com/api/rank/get_rank_by_cateid?cateid=%@&devid=D667C6BB2828EC396C5BD4139CE5C538&pcode=021000&version=3.1")
/**
 5.排行榜--详情
 */
#define KWZPushUrl (@"http://api.myhaowai.com/api/article/get_template?template=content&aid=%@&collected=0&pcode=021000&version=3.1&devid=D667C6BB2828EC396C5BD4139CE5C538")
#define KGZHPushUrl (@"http://api.myhaowai.com/api/article/get_template?template=userCenter&pcode=021000&version=3.1&devid=D667C6BB2828EC396C5BD4139CE5C538&weixin=%@&newSource=1")
//点进去后的cell
#define KXiangGuangUrl (@"http://api.myhaowai.com/api/article/get_related_article_by_aid?aid=%@&devid=D667C6BB2828EC396C5BD4139CE5C538&pcode=021000&version=3.1")

/**
 搜索
 */
#define KSeachUrl (@"http://api.myhaowai.com/api/search?devid=D667C6BB2828EC396C5BD4139CE5C538&page=%ld&pcode=021000&query=%@&version=3.1")

#define KShouyeUrl (@"http://api.myhaowai.com/api/article/get_category_list?cateId=%@&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160701204837&pageNumber=%ld&pcode=021000&version=3.1")
/*
 天下*/
 #define KTianxiaUrl (@"1497")
 /*
 上海*/
  #define KShanghaiUrl (@"1817")
/*
 旅行 */
 #define KLvxingUrl (@"1508")
 /*美食 */
 #define KMeishiUrl (@"1506")
 /*两性 */
 #define KLiangxingUrl (@"1532")
 /*美女 */
 #define KMeinvUrl (@"1546")
 /*灵异 */
 #define KLingyiUrl (@"1547")
 /*电影 */
 #define KDianyingUrl (@"1512")
 /*宠物 */
 #define KChongwuUrl (@"1525")
 /*八卦 */
 #define KBaguaUrl (@"1498")
 /*军事 */
 #define KJunshiUrl (@"1514")
 /*情感 */
 #define KQingganUrl (@"1500")
/*
 视频分类
 */

/*萌萌哒
 夜色*/
 #define KYeseUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1953&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*原创大片*/
 #define KYuanchuangUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1949&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*看天下*/
 #define KKantianxiaUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1945&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*娱乐圈*/
 #define KYulequanUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1947&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*无厘头*/
 #define KWulitouUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1948&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*高逼格*/
 #define KGaobigeUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1950&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*体育控*/
 #define KTiyukongUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1955&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*最爱玩*/
 #define KZuiaiwanUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1951&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*军事迷*/
 #define KJunshimiUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1956&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*爱生活*/
 #define KAishenghuoUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1952&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")
 /*汽车族*/
 #define KQichezuUrl (@"http://api.myhaowai.com/api/article/get_video_category_list?cateId=1957&devid=D667C6BB2828EC396C5BD4139CE5C538&direction=1&is_addpublish=0&lastId=%@&lastTime=20160614204837&pageNumber=%ld&pcode=021000&version=3.1")

 



#endif /* Const_h */

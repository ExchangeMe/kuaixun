//
//  UITabBarController+LF.h
//  TabBarWiithNavPage
//
//  Created by qianfeng1 on 16/5/26.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarController (LF)
+(void)printChildViewControlsWithViewControllers:(NSArray *)Controllers tabBarTitiles:(NSArray *)tabBarTitiles andTabBarimages:(NSArray *)tabBarimages andTabBarSelectImg:(NSArray * )tabBarSecImgs andTarget:(UITabBarController *)target;
@end

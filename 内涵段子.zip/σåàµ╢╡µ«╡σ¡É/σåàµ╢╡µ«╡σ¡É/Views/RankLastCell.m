//
//  RankLastCell.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/8.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "RankLastCell.h"
#import "UIImageView+WebCache.h"
@implementation RankLastCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(CommonModel *)model{
    _model=model;
    [_nickImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar]];
    _nickNameLabel.text=model.nickname;
    _descLabel.text=model.desc;
    _numberLabel.text=@"1";
    
}
@end

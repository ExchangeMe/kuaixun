//
//  ThreePicCell.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/2.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonModel.h"
@interface ThreePicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *FristImageView;
@property (weak, nonatomic) IBOutlet UIImageView *SecondImageView;
@property (weak, nonatomic) IBOutlet UIImageView *ThirdImageView;
@property (weak, nonatomic) IBOutlet UILabel *goryLebel;
@property (weak, nonatomic) IBOutlet UILabel *readLabel;
@property (nonatomic ,strong)CommonModel * model;

@end

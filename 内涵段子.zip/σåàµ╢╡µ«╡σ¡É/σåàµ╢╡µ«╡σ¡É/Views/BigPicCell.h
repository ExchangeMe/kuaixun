//
//  BigPicCell.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/6.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonModel.h"
@interface BigPicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *bigImageView;
@property (weak, nonatomic) IBOutlet UILabel *authorLabel;
@property (weak, nonatomic) IBOutlet UILabel *readLabel;
@property (nonatomic ,strong)CommonModel * model;
@end

//
//  LFVideoCell.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/7.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "LFVideoCell.h"
#import "Masonry.h"
#import <MediaPlayer/MPMoviePlayerController.h>
#import <MediaPlayer/MPMoviePlayerViewController.h>
#import <AVKit/AVPlayerViewController.h>
#import <AVFoundation/AVPlayer.h>

#import "UIImageView+WebCache.h"
@implementation LFVideoCell
{
     MPMoviePlayerController * _mpPlayer;
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configUI];
    }
    return self;
}

-(void)configUI{
    _videoImageView=[[UIImageView alloc]init];
    [self addSubview:_videoImageView];
    [_videoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(4);
        make.left.equalTo(self.mas_left).offset(16);
        make.right.equalTo(self.mas_right).offset(-16);
        make.height.equalTo(_videoImageView.mas_width).multipliedBy(0.75);
    }];
//     _videoImageView.userInteractionEnabled=YES;
//    
//#pragma mark _videoImageView点击手势
//    UIGestureRecognizer * top = [[UIGestureRecognizer alloc]initWithTarget:self action:@selector(playVideo:)];
//    [_videoImageView addGestureRecognizer:top];
    
    
    
   
    _titleLabel=[[UILabel alloc]init];
    [self addSubview:_titleLabel];
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoImageView.mas_top).offset(10);
        make.left.equalTo(_videoImageView.mas_left).offset(16);
        make.right.equalTo(_videoImageView.mas_right).offset(-16);
    }];
    _titleLabel.textColor=[UIColor whiteColor];
    _titleLabel.font=[UIFont boldSystemFontOfSize:17];
    
    _playImageView=[[UIImageView alloc]init];
    _playImageView.image=[UIImage imageNamed:@"play"];
    _playImageView.tintColor=[UIColor whiteColor];
    _playImageView.frame=CGRectMake(0, 0, 20, 20);
    _playImageView.center=_videoImageView.center;
    _playImageView.backgroundColor=[UIColor clearColor];
    [_videoImageView addSubview:_playImageView];
    [_playImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(_videoImageView);
    }];
    
    _weixinImageView=[[UIImageView alloc]init];
    [self addSubview:_weixinImageView];
    [_weixinImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoImageView.mas_bottom).offset(8);
        make.left.equalTo(self.mas_left).offset(20);
//        make.bottom.equalTo(self.mas_bottom).offset(-4);
        make.height.equalTo(@18);
        make.width.equalTo(@18);
        
    }];
    _weixinImageView.contentMode=UIViewContentModeScaleAspectFill;
    _weixinImageView.layer.cornerRadius=15/2;
    _weixinImageView.clipsToBounds=YES;
   
    
     _nickNameLabe=[[UILabel alloc]init];
    [self addSubview:_nickNameLabe];
    [_nickNameLabe mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoImageView.mas_bottom).offset(8);
        make.left.equalTo(_weixinImageView.mas_right).offset(10);
       make.bottom.equalTo(self.mas_bottom).offset(-4);
        make.width.equalTo(@100);
    }];
    _nickNameLabe.font=[UIFont systemFontOfSize:12];
    [_nickNameLabe setTextColor:[UIColor darkGrayColor]];
    
    _readImageView=[[UIImageView alloc]init];
    _readImageView.image=[UIImage imageNamed:@"read"];
     _readImageView.contentMode=UIViewContentModeScaleAspectFill;
    [self addSubview:_readImageView];
    [_readImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoImageView.mas_bottom).offset(8);
//        make.bottom.equalTo(self.mas_bottom).offset(-4);
        make.height.equalTo(@15);
        make.width.equalTo(@15);
        make.right.equalTo(@(-90));
    }];
    
    _readLabel=[[UILabel alloc]init];
    
    _readLabel.font=[UIFont systemFontOfSize:12];
    [_readLabel setTextColor:[UIColor darkGrayColor]];
    [self addSubview:_readLabel];
    [_readLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoImageView.mas_bottom).offset(8);
        make.left.equalTo(_readImageView.mas_right).offset(10);
        make.bottom.equalTo(self.mas_bottom).offset(-4);
        make.width.equalTo(@80);
    }];
    
}
-(void)setModel:(CommonModel *)model{
    _model=model;
//    [self configUI];
    [_videoImageView sd_setImageWithURL:[NSURL URLWithString:model.videoCovers]];
    _titleLabel.text=model.title;
    _model.videourls=model.videourls;
    [_weixinImageView sd_setImageWithURL:[NSURL URLWithString:model.weixinLogo]];
    _nickNameLabe.text=model.nickname;
    _readLabel.text=[NSString stringWithFormat:@"阅读%@",model.readNum];
    
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end

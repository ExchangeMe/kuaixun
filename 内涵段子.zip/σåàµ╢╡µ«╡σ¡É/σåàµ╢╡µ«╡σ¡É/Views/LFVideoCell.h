//
//  LFVideoCell.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/7.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonModel.h"
@interface LFVideoCell : UITableViewCell
@property (nonatomic ,strong)UILabel *  titleLabel;
@property (nonatomic ,strong)UIImageView * videoImageView;
@property (nonatomic ,strong)UIImageView * playImageView;
@property (nonatomic ,strong)UIImageView * weixinImageView;
@property (nonatomic ,strong)UILabel * nickNameLabe;
@property (nonatomic ,copy)UIImageView * readImageView;
@property (nonatomic ,copy)UILabel * readLabel;
@property (nonatomic ,strong)CommonModel * model;
@end


//
//  OnePicCell.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/6.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "OnePicCell.h"
#import "UIImageView+WebCache.h"
@implementation OnePicCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(CommonModel *)model{
    _model=model;
    _titleLabel.text=model.title;
    
    [_onlyImageView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
    _onlyImageView.clipsToBounds=YES;
    _onlyImageView.contentMode=UIViewContentModeScaleAspectFill;
    
    _authorLabel.text=model.nickname;
    if (model.readNum) {
      _readLabel.text=[NSString stringWithFormat:@"阅读:%@",model.readNum];
    }
   
}
@end

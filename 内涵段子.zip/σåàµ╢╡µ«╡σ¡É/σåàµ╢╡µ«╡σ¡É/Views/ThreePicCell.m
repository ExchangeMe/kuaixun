//
//  ThreePicCell.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/2.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "ThreePicCell.h"
#import "UIImageView+WebCache.h"
@implementation ThreePicCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(CommonModel *)model{
    
    _model=model;
    
    _titleLabel.text=model.title;
   
    [_FristImageView sd_setImageWithURL:[NSURL URLWithString:model.imgList[0]]];
    [_SecondImageView sd_setImageWithURL:[NSURL URLWithString:model.imgList[1]]];
    [_ThirdImageView sd_setImageWithURL:[NSURL URLWithString:model.imgList[2]]];
    
    _goryLebel.text=model.nickname;
    _readLabel.text=[NSString stringWithFormat:@"阅读:%@",model.readNum];
    
}
@end

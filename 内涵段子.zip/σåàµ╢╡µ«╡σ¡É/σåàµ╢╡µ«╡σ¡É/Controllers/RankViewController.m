//
// kViewController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/1.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "RankViewController.h"
#import "RankTableViewController.h"
#import "RankgoryModel.h"
#import "AFNetworking.h"
#import "Const.h"

#define KWIDHT [UIScreen mainScreen].bounds.size.width
#define KHEIGHT [UIScreen mainScreen].bounds.size.height
@interface RankViewController ()<UIScrollViewDelegate>
{
    NSMutableArray * _dataArray;
    UIScrollView * _topScrollView;
    NSMutableArray * _btnsArray;
    UIScrollView * _bgScrollView;
    RankTableViewController * _rank;
    NSMutableArray * _dataArr;
    
    UIButton * _tmpBtn;
    UIButton * _tmpBtn1;
    UIView * _line;
}
@end

@implementation RankViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden=NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     self.automaticallyAdjustsScrollViewInsets=NO;
    [self setupVcArr];
    [self leftScroll];
    [self titleBtnScroll];
    [self setupBgScroll];
}

#pragma mark--数据源
-(void)setupVcArr{
    _dataArray=[[NSMutableArray alloc]init];
    for (NSInteger i = 0; i<2;i++) {
        RankTableViewController * sub = [[RankTableViewController alloc]init];
        sub.index=i;
        [_dataArray addObject:sub];
        [self addChildViewController:sub];//共享导航栏控制器nav
    }
}

#pragma mark--左边视图
-(void)leftScroll{
    _dataArr=[NSMutableArray array ];

    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
     [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:KRankgoryUrl parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSArray * models=[RankgoryModel arrayOfModelsFromDictionaries:responseObject[@"category_list"]];
        [_dataArr addObjectsFromArray:models];
        
        
        UIScrollView * leftScroll=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT/4, KHEIGHT)];
        leftScroll.backgroundColor=[UIColor colorWithWhite:0.9 alpha:1];
        
        for (NSInteger i = 0; i<_dataArr.count; i++) {
            UIButton * btn =[[UIButton alloc]initWithFrame:CGRectMake(0, 0+50*i, leftScroll.frame.size.width, 50)];
            RankgoryModel * model=_dataArr[i];

            [btn setTitle:model.category_name forState:UIControlStateNormal];
           
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            btn.tag=1000+i;
            if (i==0) {
                btn.selected=YES;
                _tmpBtn=btn;
                _rank=_dataArray[0];
                _rank.cate_id=model.type_id;
                [_rank loadData];
                _rank=_dataArray[1];
                _rank.cate_id=model.type_id;
                [_rank loadData];
                
            }
            
            if (_tmpBtn.selected==YES) {
                [_tmpBtn setBackgroundColor:[UIColor whiteColor]];
            }
            
            [leftScroll addSubview:btn];
        }
        
        leftScroll.contentSize=CGSizeMake(KWIDHT/4, _dataArr.count*50+100);
        leftScroll.contentOffset=CGPointMake(0, 0);
        
        [self.view addSubview:leftScroll];
        
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
    }];
  
}

-(void)btnClick:(UIButton *)btn{
     RankgoryModel * model = _dataArr[btn.tag-1000];
    _tmpBtn.selected=NO;
    _tmpBtn.backgroundColor=[UIColor colorWithWhite:0.9 alpha:1];
    btn.selected=YES;
    [btn setBackgroundColor:[UIColor whiteColor]];
    _tmpBtn=btn;
   

    
        _rank=_dataArray[0];
        _rank.cate_id=model.type_id;
        [_rank loadData];
 
        _rank=_dataArray[1];
        _rank.cate_id=model.type_id;
        [_rank loadData];
    
   
}
#pragma mark--右上按键
-(void)titleBtnScroll{
    _btnsArray=[NSMutableArray array];
    UIScrollView * titleScroll=[[UIScrollView alloc]initWithFrame:CGRectMake(KWIDHT/4, 0, 3*KWIDHT/4, 40)];

    NSArray * titles=@[@"文章",@"公众号"];
    for (NSInteger i = 0; i<2; i++) {
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(i*titleScroll.frame.size.width/2, 0, titleScroll.frame.size.width/2, 40-2)];
        
        [btn setTitle:titles[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithRed:0.8 green:0 blue:0 alpha:1] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(btnClick1:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag=100+i;
        if (i==0) {
            btn.selected=YES;
            _tmpBtn1=btn;
        }
        [titleScroll addSubview:btn];
        [_btnsArray addObject:btn];
    }
    titleScroll.contentOffset=CGPointMake(KWIDHT/4, 0);
    titleScroll.contentSize=CGSizeMake(3*KWIDHT/4, 40);
    [self.view addSubview:titleScroll];
    
    _line=[[UIView alloc]initWithFrame:CGRectMake(0, 40-2, titleScroll.frame.size.width/2, 2)];
    _line.backgroundColor=[UIColor colorWithRed:0.8 green:0 blue:0 alpha:1];
    [titleScroll addSubview:_line];
    
    _topScrollView=titleScroll;
}

-(void)btnClick1:(UIButton *)btn{
    
    if (btn!=_tmpBtn1) {
        _tmpBtn1.selected=NO;
        btn.selected=YES;
        _tmpBtn1=btn;
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect =_line.frame;
            rect.origin.x = btn.frame.origin.x;
            _line.frame=rect;
            
            _bgScrollView.contentOffset=CGPointMake((KWIDHT*3/4)*(btn.frame.origin.x/btn.frame.size.width), 0);
            NSInteger i =btn.frame.origin.x/btn.frame.size.width;
            RankTableViewController * subVC = _dataArray[i];

            //判断是否被加父视图
            if (!subVC.view.superview) {
                subVC.view.frame=CGRectMake((3*KWIDHT/4)*i, 0, 3*KWIDHT/4, KHEIGHT-40);
                RankgoryModel * model = _dataArr[_tmpBtn.tag-1000];
                subVC.cate_id=model.type_id;
                [subVC loadData];
                [_bgScrollView addSubview:subVC.view];
                
               
            }
            
        }];
    }
   
}

#pragma 核心大的cell bgScroll
-(void)setupBgScroll{
  
    UIScrollView * bgScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(KWIDHT/4, 40, 3*KWIDHT/4, KHEIGHT-40)];
    bgScroll.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:bgScroll];
    RankTableViewController * subvc = _dataArray[0];
    subvc.view.frame=CGRectMake(0, 0, 3*KWIDHT/4, KHEIGHT-40);
    bgScroll.delegate=self;
    bgScroll.pagingEnabled=YES;
    bgScroll.showsHorizontalScrollIndicator=NO;
    bgScroll.bounces=NO;
    bgScroll.contentSize=CGSizeMake(2*3*KWIDHT/4, 0);
    [bgScroll addSubview:subvc.view];
    
    _bgScrollView=bgScroll;
   
}
#pragma mark--bgScrollView的delegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = scrollView.contentOffset.x/(3*KWIDHT/4);
    RankTableViewController * subVC = _dataArray[index];
    
    //判断是否被加父视图
    if (!subVC.view.superview) {
        subVC.view.frame=CGRectMake((3*KWIDHT/4)*index, 0, (3*KWIDHT/4),KHEIGHT-40);
        RankgoryModel * model = _dataArr[_tmpBtn.tag-1000];
        subVC.cate_id=model.type_id;
        [subVC loadData];
        [scrollView addSubview:subVC.view];
   
    }
    
    if (index==1) {
        
//        
//        RankgoryModel * model = _dataArr[_tmpBtn.tag-1000];
//        subVC.cate_id=model.type_id;
////        NSLog(@"%@",model.type_id);
//        
//        [subVC loadData];
       
        
        UIButton *btn1=_btnsArray[0];
        btn1.selected=NO;
        UIButton *btn=_btnsArray[1];
        btn.selected=YES;
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect =_line.frame;
            rect.origin.x = btn.frame.origin.x;
            _line.frame=rect;
        }];
    }else if (index==0) {
//        RankgoryModel * model = _dataArr[_tmpBtn.tag-1000];
//        subVC.cate_id=model.type_id;
//        [subVC loadData];
        
        UIButton *btn=_btnsArray[index];
        btn.selected=YES;
        UIButton *btn1=_btnsArray[1];
        btn1.selected=NO;
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect =_line.frame;
            rect.origin.x = btn.frame.origin.x;
            _line.frame=rect;
            
         
            
        }];
        
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

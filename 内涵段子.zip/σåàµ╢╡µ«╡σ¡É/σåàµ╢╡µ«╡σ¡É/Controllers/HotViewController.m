//
//  HotViewController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/1.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "HotViewController.h"

#import "CommonModel.h"
#import "Const.h"
#import "MJRefresh.h"
#import "AFNetworking.h"
#import "ThreePicCell.h"
#import "OnePicCell.h"
#import "BigPicCell.h"
#import "LFRankDetailVC.h"
#define KWIDHT [UIScreen mainScreen].bounds.size.width

#define KHEIGHT [UIScreen mainScreen].bounds.size.height
@interface HotViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;
    NSInteger _curPage;
    NSString *  _lastId;//参数
    CommonModel * _model;//带参数
    UILabel * _imageView;
}
@end

@implementation HotViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden=NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _dataArray =[NSMutableArray array ];
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT-64) style:UITableViewStylePlain];
    [_tb registerNib: [UINib nibWithNibName:@"ThreePicCell" bundle:nil]  forCellReuseIdentifier:@"ThreePicCell"];
    [_tb registerNib: [UINib nibWithNibName:@"OnePicCell" bundle:nil]  forCellReuseIdentifier:@"OnePicCell"];
    [_tb registerNib: [UINib nibWithNibName:@"BigPicCell" bundle:nil]  forCellReuseIdentifier:@"BigPicCell"];
    _tb.delegate = self;
    _tb.dataSource = self;
    [self.view addSubview:_tb];
    //初始化数据源
    _dataArray = [[NSMutableArray alloc]init];
    //添加上下拉刷新
    _tb.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    //添加上拉加载更多
    _tb.footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
    //开启头部刷新
    [_tb.header beginRefreshing];
    
    
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    
   _tb.tableFooterView = [[UIView alloc] init]; 
}

- (void)refresh
{
    if (_dataArray) {
        [_dataArray removeAllObjects];
    }
    _curPage ++;
    _lastId=[_dataArray.firstObject lastId];
    //加载数据
    [self loadData];
    if (_curPage==4) {
        _curPage=3;
    }
}

- (void)loadMore
{
    _curPage ++;
    
    _lastId=[_dataArray.lastObject lastId];
    //加载数据
    [self loadData];
    if (_curPage==5) {
        _curPage=4;
    }
    
    
}
-(void)loadData{
    
    NSString * urlStr = [NSString stringWithFormat:KReDianUrl,_lastId, (long)_curPage];
   
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:urlStr parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"contentList"]];
        [_dataArray addObjectsFromArray:models];
        [_tb reloadData];
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
        [_imageView removeFromSuperview];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        if (_curPage != 1) {
            _curPage--;
        }
        _imageView=[[UILabel alloc]initWithFrame:CGRectMake(0,-64-50, 100, 100)];
        _imageView.center=self.view.center;
        _imageView.text=@"加载失败~\n请检查网络";
        _imageView.font=[UIFont systemFontOfSize:12];
        _imageView.textColor=[UIColor darkGrayColor];
        [self.view addSubview:_imageView];
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
    }];
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CommonModel * model = _dataArray[indexPath.row];
    
    //    for (CommonModel * model in _dataArray) {
    
    
    if ([model.showType isEqualToString: @"small"]) {
        ThreePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"ThreePicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;
        
    }else if([model.showType isEqualToString:@"cover"]){
        OnePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"OnePicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;
        
    }else if ([model.showType isEqualToString:@"big"]){
        BigPicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BigPicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;
    }else{
        return nil;
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonModel * model = _dataArray[indexPath.row];
    LFRankDetailVC * vc =[[LFRankDetailVC alloc]init];
    vc.index=0;
    vc.aid=model.aid;
    vc.isVideo=0;
    vc.imgurl=model.imgurl;
    vc.niceTitle=model.title;
    [self.navigationController pushViewController:vc animated:YES];
    self.tabBarController.tabBar.hidden=YES;
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
//
//  HotViewController.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/1.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotViewController : UIViewController

@end

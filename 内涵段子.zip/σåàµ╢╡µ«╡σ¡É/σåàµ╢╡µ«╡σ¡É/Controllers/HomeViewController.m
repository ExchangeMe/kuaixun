//
//  HomeViewController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/1.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "HomeViewController.h"
#import "CommonModel.h"
#import "Const.h"
#import "MJRefresh.h"
#import "AFNetworking.h"
#import "ThreePicCell.h"
#import "OnePicCell.h"
#import "BigPicCell.h"
#import "LFRankDetailVC.h"
#define KWIDHT [UIScreen mainScreen].bounds.size.width

#define KHEIGHT [UIScreen mainScreen].bounds.size.height
@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;
    NSInteger _curPage;
    NSString *  _lastId;//参数
    CommonModel * _model;//带参数
    UILabel * _imageView;
    NSString * _urlStr;
}
@end

@implementation HomeViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden=NO;
    self.tabBarController.tabBar.hidden=NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT-64-40) style:UITableViewStylePlain];
    [_tb registerNib: [UINib nibWithNibName:@"ThreePicCell" bundle:nil]  forCellReuseIdentifier:@"ThreePicCell"];
    [_tb registerNib: [UINib nibWithNibName:@"OnePicCell" bundle:nil]  forCellReuseIdentifier:@"OnePicCell"];
    [_tb registerNib: [UINib nibWithNibName:@"BigPicCell" bundle:nil]  forCellReuseIdentifier:@"BigPicCell"];
    _tb.delegate = self;
    _tb.dataSource = self;
   [self.view addSubview:_tb]; 
    //初始化数据源
    _dataArray = [[NSMutableArray alloc]init];
    //添加上下拉刷新
    _tb.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    //添加上拉加载更多
    _tb.footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
    //开启头部刷新
    [_tb.header beginRefreshing];
    _dataArray =[NSMutableArray array ];
    
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    
    _tb.tableFooterView = [[UIView alloc] init];
    
}

- (void)refresh
{
    [_dataArray removeAllObjects];
    _curPage ++;
    _lastId=[_dataArray.firstObject lastId];
    //加载数据
    [self loadData];
}

- (void)loadMore
{
   
    _lastId=[_dataArray.lastObject lastId];
        //加载数据
        [self loadData];
  
}
-(void)loadData{
    switch (_index) {
        case 0:
              _urlStr = [NSString stringWithFormat:KTuiJianUrl,_lastId, (long)_curPage];
            break;
        case 1:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KTianxiaUrl,_lastId, (long)_curPage];
            break;
        case 2:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KShanghaiUrl,_lastId, (long)_curPage];
            break;
        case 3:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KLvxingUrl,_lastId,(long)_curPage];
            break;
        case 4:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KMeishiUrl,_lastId, (long)_curPage];
            break;
        case 5:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KLiangxingUrl,_lastId,(long)_curPage];
            break;
        case 6:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KMeinvUrl,_lastId, (long)_curPage];
            break;
        case 7:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KLingyiUrl,_lastId, (long)_curPage];
            break;
        case 8:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KDianyingUrl,_lastId, (long)_curPage];
            break;
        case 9:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KChongwuUrl,_lastId, (long)_curPage];
            break;
        case 10:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KBaguaUrl,_lastId, (long)_curPage];
            break;
        case 11:
              _urlStr = [NSString stringWithFormat:KShouyeUrl,KJunshiUrl,_lastId, (long)_curPage];
            break;
        default:
            break;
    }
    
    

    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:_urlStr parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {

        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"contentList"]];
        [_dataArray addObjectsFromArray:models];
        [_tb reloadData];
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
        [_imageView removeFromSuperview];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        if (_curPage != 1) {
            _curPage--;
        }
        _imageView=[[UILabel alloc]initWithFrame:CGRectMake(0,-64-50, 100, 100)];
        _imageView.center=self.view.center;
        _imageView.textAlignment=NSTextAlignmentCenter;
        _imageView.text=@"加载失败~\n请检查网络";
        _imageView.font=[UIFont systemFontOfSize:12];
        _imageView.textColor=[UIColor darkGrayColor];
        [self.view addSubview:_imageView];
        
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
    }];
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

        CommonModel * model = _dataArray[indexPath.row];
    
//    for (CommonModel * model in _dataArray) {
    
    
    if ([model.showType isEqualToString: @"small"]) {
        ThreePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"ThreePicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;
        
    }else if([model.showType isEqualToString:@"cover"]){
        OnePicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"OnePicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;

    }else if ([model.showType isEqualToString:@"big"]){
        BigPicCell * cell = [tableView dequeueReusableCellWithIdentifier:@"BigPicCell" forIndexPath:indexPath];
        
        cell.model=model;
        return cell;
    }else{
        return nil;
    }
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonModel * model = _dataArray[indexPath.row];
    LFRankDetailVC * vc =[[LFRankDetailVC alloc]init];
    vc.index=0;
    vc.aid=model.aid;
    vc.isVideo=0;
    vc.imgurl=model.imgurl;
    vc.niceTitle=model.title;
    [self.navigationController pushViewController:vc animated:YES];
    self.tabBarController.tabBar.hidden=YES;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [_dataArray removeAllObjects];
    
}


@end

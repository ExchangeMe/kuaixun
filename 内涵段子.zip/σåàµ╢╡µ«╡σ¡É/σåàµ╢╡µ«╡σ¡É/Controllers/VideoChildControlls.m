//
//  VideoChildControlls.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/7.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "VideoChildControlls.h"
#import "CommonModel.h"
#import "MJRefresh.h"
#import "Const.h"
#import "LFVideoCell.h"
#import "AFNetworking.h"
#import <AVFoundation/AVAudioSession.h>
#import <MediaPlayer/MPMoviePlayerController.h>
#import "LFRankDetailVC.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVPlayerViewController.h>
#define KWIDHT [UIScreen mainScreen].bounds.size.width

#define KHEIGHT [UIScreen mainScreen].bounds.size.height
@interface VideoChildControlls ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;
    NSInteger _curPage;
    NSString * _lastId;
    CommonModel * _model;
    NSString * _urlStr;
    AVPlayerViewController * _mpPlayer;
//    MPMoviePlayerController * _mpPlayer;
}
@end

@implementation VideoChildControlls

- (void)viewDidLoad {
    [super viewDidLoad];
    _dataArray =[NSMutableArray array ];
      _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT, KHEIGHT-64-49) style:UITableViewStylePlain];
    _tb.delegate = self;
    _tb.dataSource = self;
    [self.view addSubview:_tb];
    //初始化数据源
    _dataArray = [[NSMutableArray alloc]init];
    //添加上下拉刷新
    _tb.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    //添加上拉加载更多
    _tb.footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
    //开启头部刷新
    [_tb.header beginRefreshing];
    
    
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    
    _tb.tableFooterView = [[UIView alloc] init];
}

- (void)refresh
{
    if (_dataArray) {
        [_dataArray removeAllObjects];
    }
    _curPage ++;
    _lastId=[_dataArray.firstObject lastId];
    //加载数据
    [self loadData];
}

- (void)loadMore
{
    _curPage --;
    
    _lastId=[_dataArray.lastObject lastId];
    //加载数据
    [self loadData];
    if (_curPage==0) {
        _curPage=1;
    }
    
    
}
-(void)loadData{
    
    
    
    switch (_index) {
        case 0:
            _urlStr = [NSString stringWithFormat:KShiPinUrl,_lastId, (long)_curPage];;
            break;
        case 1:
            _urlStr = [NSString stringWithFormat:KYeseUrl,_lastId, (long)_curPage];
            break;
        case 2:
            _urlStr = [NSString stringWithFormat:KYuanchuangUrl,_lastId,(long)_curPage];
            break;
        case 3:
            _urlStr = [NSString stringWithFormat:KKantianxiaUrl,_lastId, (long)_curPage];
            break;
        case 4:
            _urlStr = [NSString stringWithFormat:KYulequanUrl,_lastId, (long)_curPage];
            break;
        case 5:
            _urlStr = [NSString stringWithFormat:KWulitouUrl,_lastId, (long)_curPage];
            break;
        case 6:
            _urlStr = [NSString stringWithFormat:KGaobigeUrl,_lastId, (long)_curPage];
            break;
        case 7:
            _urlStr = [NSString stringWithFormat:KTiyukongUrl,_lastId, (long)_curPage];
            break;
        case 8:
            _urlStr = [NSString stringWithFormat:KZuiaiwanUrl,_lastId, (long)_curPage];
            break;
        case 9:
            _urlStr = [NSString stringWithFormat:KJunshimiUrl,_lastId, (long)_curPage];
            break;
        case 10:
            _urlStr = [NSString stringWithFormat:KAishenghuoUrl,_lastId, (long)_curPage];
            break;
        case 11:
            _urlStr = [NSString stringWithFormat:KQichezuUrl,_lastId, (long)_curPage];
            break;
        default:
            break;
    }
    
    
    
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:_urlStr parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"contentList"]];
        [_dataArray addObjectsFromArray:models];
        [_tb reloadData];
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        if (_curPage != 1) {
            _curPage--;
        }
        
        [_tb.header endRefreshing];
        [_tb.footer endRefreshing];
    }];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LFVideoCell * cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell=[[LFVideoCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    }
    else {
     _mpPlayer.view.backgroundColor=[UIColor blackColor];
    }
    CommonModel * model = _dataArray[indexPath.row];
    cell.model=model;
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playVideo:)];
    cell.videoImageView.userInteractionEnabled = YES;
    [cell.videoImageView addGestureRecognizer:tap];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
   
    NSIndexPath * testPath = [tableView indexPathForCell:[_mpPlayer.view.superview valueForKey:@"superview"]];
   
    if (indexPath == testPath) {
        [_mpPlayer.player pause];
        [_mpPlayer.player setRate:0.0];
        [_mpPlayer.view removeFromSuperview];
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    CommonModel * model = _dataArray[indexPath.row];
    LFRankDetailVC * vc =[[LFRankDetailVC alloc]init];
    vc.videourls=model.videourls;
    vc.index=0;
    vc.aid=model.aid;
    vc.category=@"video";
    vc.isVideo=1;
    vc.imgurl=model.imgurl;
    vc.niceTitle=model.title;
     [_mpPlayer.player pause];
    [_mpPlayer.player setRate:0.0];
    [_mpPlayer.view removeFromSuperview];
   
    [self.navigationController pushViewController:vc animated:YES];
    self.tabBarController.tabBar.hidden=YES;
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)playVideo:(UITapGestureRecognizer *)tap {
 
    if (_mpPlayer) {
         [_mpPlayer.player pause];
        [_mpPlayer.player setRate:0.0];
        [_mpPlayer.view removeFromSuperview];
    }
    UIImageView * videoImageView = [tap valueForKey:@"view"];
    NSURL * url = [NSURL URLWithString:[tap.view.superview valueForKeyPath:@"model.videourls"]];
    
    AVPlayerViewController * vc = [[AVPlayerViewController alloc]init];
    AVPlayer * play =[[AVPlayer alloc]initWithURL:url];
    vc.player=play;
    [play play];
    vc.view.frame=CGRectMake(0, 0, videoImageView.frame.size.width, videoImageView.frame.size.height);
    [videoImageView addSubview:vc.view];
    
    _mpPlayer=vc;//全局变量 好控制播放和暂停

    vc.view.backgroundColor=[UIColor blackColor];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];

}
#pragma mark-释放mpPlay
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [_mpPlayer.player pause];
    [_mpPlayer.player setRate:0.0];
    [_mpPlayer.view removeFromSuperview];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden=NO;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

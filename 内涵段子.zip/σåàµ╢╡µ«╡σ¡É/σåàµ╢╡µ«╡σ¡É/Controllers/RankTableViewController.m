//
//  RankTableViewController.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/8.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "RankTableViewController.h"
#import "OnePicCell.h"
#import "Const.h"
#import "AFNetworking.h"
#import "RankLastCell.h"
#import "LFRankDetailVC.h"

#define KWIDHT [UIScreen mainScreen].bounds.size.width
#define KHEIGHT [UIScreen mainScreen].bounds.size.height
@interface RankTableViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tb;
    NSMutableArray * _dataArray;

    NSInteger _curPage;
    LFRankDetailVC * _rankDetatil;
    
}
@end

@implementation RankTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   

    self.view.backgroundColor=[UIColor whiteColor];
//    NSLog(@"---%ld",_index);
    
    _tb=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, KWIDHT*3/4, KHEIGHT-64-40-49) style:UITableViewStylePlain];
    _tb.delegate=self;
    _tb.dataSource=self;
    [self.view addSubview:_tb];
    [_tb registerNib:[UINib nibWithNibName:@"OnePicCell" bundle:nil] forCellReuseIdentifier:@"OnePicCe"];
//还可以注册公众号
    [_tb registerNib:[UINib nibWithNibName:@"RankLastCell" bundle:nil] forCellReuseIdentifier:@"RankLastCell"];
//    [self loadData];
    _tb.rowHeight=UITableViewAutomaticDimension;
    _tb.estimatedRowHeight=100;
    [_tb reloadData];
       _dataArray=[NSMutableArray array];
    
    _tb.tableFooterView = [[UIView alloc] init];
}


-(void)loadData{

    if (_dataArray) {
        [_dataArray removeAllObjects];
    }
    
    NSString * url ;
    if (_index==0) {
        
      url = [NSString stringWithFormat:KWenzhangURl,_cate_id];
        
    }else if(_index==1){
       
        url=[NSString stringWithFormat:KGongzonghaoUrl,_cate_id];
       
    }
    
//  NSLog(@"%@",url);

    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/html",@"application/json",nil]];
    [manager GET:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray * models =[CommonModel arrayOfModelsFromDictionaries:responseObject[@"list"]];
    
            [_dataArray addObjectsFromArray:models];
     
        [_tb reloadData];
         } failure:^(NSURLSessionDataTask *task, NSError *error) {
             
         }];
      [_tb reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  
        return _dataArray.count;
  
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (_index==0) {
        
    OnePicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OnePicCe" forIndexPath:indexPath];
    
    cell. model=_dataArray[indexPath.row];
    cell.readLabel.hidden=YES;
        return cell;
    }else if(_index==1) {
        RankLastCell * cell=[tableView dequeueReusableCellWithIdentifier:@"RankLastCell"];
   
        cell.model=_dataArray[indexPath.row];
        cell.nickImageView.layer.cornerRadius=30;
        cell.nickImageView.clipsToBounds=YES;
        cell.numberLabel.text=[NSString stringWithFormat:@"%ld",(long)(indexPath.row+1)];
        
        if (indexPath.row>=0&&indexPath.row<3) {
              cell.numberLabel.textColor=[UIColor redColor];
        }else{
             cell.numberLabel.textColor=[UIColor darkGrayColor];
        }
        return cell;
      
    }
    return nil;
}
#pragma mark--点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonModel * model = _dataArray[indexPath.row];
    _rankDetatil =[[LFRankDetailVC alloc]init];
    
    _rankDetatil.index=_index;
    _rankDetatil.weinxin=model.weixin;
    _rankDetatil.aid=model.aid;
    _rankDetatil.isVideo=0;
    _rankDetatil.imgurl=model.imgurl;
    _rankDetatil.niceTitle=model.title;
    
//    self.tabBarController.hidesBottomBarWhenPushed=YES;
    self.tabBarController.tabBar.hidden=YES;
    [self.navigationController pushViewController:_rankDetatil animated:YES];
    
}


@end

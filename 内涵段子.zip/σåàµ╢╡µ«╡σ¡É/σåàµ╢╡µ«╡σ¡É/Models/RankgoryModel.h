//
//  RankgoryModel.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/8.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "JSONModel.h"

@interface RankgoryModel : JSONModel
@property (nonatomic ,copy)NSString * category_name;
@property (nonatomic ,copy)NSString * type_id;
//@property (nonatomic ,copy)NSString * imgurl;
//@property (nonatomic ,copy)NSString * ios_key;
@end

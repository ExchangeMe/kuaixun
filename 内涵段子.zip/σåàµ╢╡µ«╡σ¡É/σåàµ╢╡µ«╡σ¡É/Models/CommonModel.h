//
//  CommonModel.h
//  内涵段子
//
//  Created by qianfeng1 on 16/6/7.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "JSONModel.h"

@interface CommonModel : JSONModel
@property (nonatomic ,copy)NSString * aid;
@property (nonatomic ,copy)NSString * imgurl;
@property (nonatomic ,copy)NSString * lastId;
@property (nonatomic ,copy)NSString * nickname;
@property (nonatomic ,copy)NSString * readNum;
@property (nonatomic ,copy)NSString * showType;
@property (nonatomic ,copy)NSString * title;
//@property (nonatomic ,copy)NSString * typeid;
@property (nonatomic ,copy)NSArray * imgList;
@property (nonatomic ,copy)NSString* videoCovers;
@property (nonatomic ,copy)NSString * videourls;
@property (nonatomic ,copy)NSString * weixinLogo;
@property (nonatomic ,copy)NSString * weixin;
@property (nonatomic ,copy)NSString * avatar;
@property (nonatomic ,copy)NSString * desc;

@property (nonatomic ,assign)NSInteger isVideo;//判断是不是视频
@property (nonatomic ,assign)NSInteger index;//判断是公众号还是文章详情

@end

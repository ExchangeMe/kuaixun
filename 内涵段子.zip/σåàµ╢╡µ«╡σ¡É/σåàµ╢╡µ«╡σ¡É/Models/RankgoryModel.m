//
//  RankgoryModel.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/8.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "RankgoryModel.h"

@implementation RankgoryModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
+(JSONKeyMapper *)keyMapper{
    return [[JSONKeyMapper alloc]initWithDictionary:@{@"typeid":@"type_id"}];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end

//
//  CommonModel.m
//  内涵段子
//
//  Created by qianfeng1 on 16/6/7.
//  Copyright (c) 2016年 LU_FENG. All rights reserved.
//

#import "CommonModel.h"

@implementation CommonModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
